import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_cors import CORS
from flask_bcrypt import Bcrypt
from flask_jwt_extended import JWTManager, create_access_token, get_jwt_identity, jwt_required, verify_jwt_in_request, get_jwt, unset_jwt_cookies
from flask_migrate import Migrate
from datetime import timedelta
from sqlalchemy import asc, desc
from extensions import db
from models import Product, Customer, Order, User
import os
import random
import string


bcrypt = Bcrypt()
jwt = JWTManager()
migrate = Migrate()
cors = CORS()

app = Flask(__name__,
            template_folder=os.path.join(os.path.dirname(__file__), '../templates'),
            static_folder=os.path.join(os.path.dirname(__file__), '../static'))

basedir = os.path.abspath(os.path.dirname(__file__))

# Configuration
app.config['SECRET_KEY'] = 'super-secret'
app.config['JWT_SECRET_KEY'] = 'super-secret'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///' + os.path.join(basedir, 'users.db')
app.config['JWT_TOKEN_LOCATION'] = ['cookies']
app.config['JWT_ACCESS_COOKIE_NAME'] = 'access_token_cookie'
app.config['JWT_COOKIE_SECURE'] = False  # Change to True in prod
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=1)

# Initialize extensions with app
db.init_app(app)
bcrypt.init_app(app)
jwt.init_app(app)
migrate.init_app(app, db)
cors.init_app(app)

if not os.path.exists('users.db'):
    with app.app_context():
        db.create_all()

with app.app_context():
    db.create_all()  # Create tables if not exist
    print(Customer.query.all())
    # Check if admin exists
    admin_email = 'admin123@example.com'
    admin_password = 'admin123'
    existing_admin = User.query.filter_by(email=admin_email, role='admin').first()
    if not existing_admin:
        hashed_pw = bcrypt.generate_password_hash(admin_password).decode('utf-8')
        admin = User(name='Admin', email=admin_email, password=hashed_pw, role='admin')
        db.session.add(admin)
        db.session.commit()


@app.route('/')
def index():
    user_name = None
    try:
        print("Verifying JWT in request...")
        verify_jwt_in_request(optional=True)
        print("JWT verified!")
        
        claims = get_jwt()
        print("Claims:", claims)
        
        user_name = claims.get('name')
        print("User name extracted:", user_name)
    except Exception as e:
        print("Exception caught:", e)

    return render_template('index.html', user_name=user_name)

@app.route('/')
def home():
    return render_template('index.html', user_name=session.get('user_name'))


DATABASE = os.path.join(os.path.dirname(__file__), 'users.db')

def get_db():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

# def seed_admin():
#     conn = get_db()
#     cur = conn.cursor()

#     # Debug: list all tables
#     cur.execute("SELECT name FROM sqlite_master WHERE type='table';")
#     tables = [row["name"] for row in cur.fetchall()]
#     print("📦 Tables in DB:", tables)

#     # Fix table name to "user" (not "users")
#     cur.execute("SELECT * FROM user WHERE email = ?", ('admin@example.com',))
#     if not cur.fetchone():
#         password = bcrypt.hashpw('admin123'.encode('utf-8'), bcrypt.gensalt())
#         cur.execute(
#             "INSERT INTO user (email, password,name,  role) VALUES (?, ?, ?, ?)",
#             ('admin@example.com', password, 'Admin', 'admin')
#         )

# seed_admin()



from models import User  # ✅ Ensure this import matches your folder structure

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')

    email = request.form.get('email')
    password = request.form.get('password')
    role = request.form.get('role')

    if not email or not password or not role:
        return render_template('login.html', error="All fields are required.")

    if role == 'admin':
        user = User.query.filter_by(email=email, role='admin').first()
        if user and bcrypt.check_password_hash(user.password, password):
            token = create_access_token(
                identity=user.email,  # must be a string
                additional_claims={
                    'role': user.role,
                    'name': user.name  # Send only first name here
                }
            )
            resp = make_response(redirect(url_for('admin_dashboard')))
            resp.set_cookie('access_token_cookie', token, httponly=True)
            return resp
        return render_template('login.html', error="Invalid admin credentials")

    user = User.query.filter_by(email=email, role='customer').first()
    if user and bcrypt.check_password_hash(user.password, password):
        token = create_access_token(
            identity=user.email,  # must be a string
            additional_claims={
                'role': user.role,
                'name': user.name  # Send only first name here
            }
        )
        resp = make_response(redirect(url_for('customer_dashboard')))
        resp.set_cookie('access_token_cookie', token, httponly=True)
        return resp

    return render_template('login.html', error="Invalid customer credentials")

# routes/admin.py or your main app file

@app.route('/register', methods=['GET'])
def register_form():
    return render_template('register.html')



@app.route('/register', methods=['POST'])
def register():
    data = request.json
    email = data.get('email')
    name = data.get('name')
    password = data.get('password')
    role = 'customer'  # Default to customer

    if not email or not name or not password:
        return jsonify({'msg': 'All fields are required'}), 400

    hashed_pw = bcrypt.generate_password_hash(password).decode('utf-8')

    try:
        # Add to 'user' table
        user = User(name=name, email=email, password=hashed_pw, role=role)
        db.session.add(user)

        # Also add to 'customer' table
        customer = Customer(name=name, email=email, password=hashed_pw)
        db.session.add(customer)

        db.session.commit()
        return jsonify({'msg': 'Customer registered successfully'}), 201

    except Exception as e:
        db.session.rollback()
        if 'UNIQUE constraint failed' in str(e):
            return jsonify({'msg': 'Email already exists'}), 409
        return jsonify({'msg': 'Registration failed'}), 500


def debug_tables():
    conn = get_db()
    cur = conn.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = cur.fetchall()
    print("🛠 Available tables:", [t[0] for t in tables])

# Call this after get_db()
debug_tables()

@app.route('/customer/dashboard')
@jwt_required()
def customer_dashboard():
    claims = get_jwt()
    if claims['role'] != 'customer':
        return redirect(url_for('login'))

    db = get_db()
    user = db.execute("SELECT * FROM user WHERE email = ?", (claims['sub'],)).fetchone()
    return render_template('customer_dashboard.html', user=user)

@app.route('/update_profile', methods=['POST'])
@jwt_required()
def update_profile():
    claims = get_jwt()
    if claims['role'] != 'customer':
        return redirect('/login')

    name = request.form['name']
    db = get_db()
    db.execute("UPDATE user SET name = ? WHERE email = ?", (name, claims['sub']))
    db.commit()
    flash("Profile updated.")
    return redirect(url_for('customer_dashboard'))

@app.route('/change_password', methods=['POST'])
@jwt_required()
def change_password():
    claims = get_jwt()
    if claims['role'] != 'customer':
        return redirect('/login')

    current = request.form['current_password']
    new = request.form['new_password']
    confirm = request.form['confirm_password']

    if new != confirm:
        flash("Passwords do not match.")
        return redirect(url_for('customer_dashboard'))

    db = get_db()
    user = db.execute("SELECT * FROM user WHERE email = ?", (claims['sub'],)).fetchone()

    if not bcrypt.check_password_hash(user['password'], current):
        flash("Current password is incorrect.")
        return redirect(url_for('customer_dashboard'))

    hashed = bcrypt.generate_password_hash(new).decode('utf-8')
    db.execute("UPDATE user SET password = ? WHERE email = ?", (hashed, claims['sub']))
    db.commit()
    flash("Password changed.")
    return redirect(url_for('customer_dashboard'))



@app.route('/admin/dashboard')
def admin_dashboard():
    db = get_db()

    total_products = Product.query.count()
    total_customers = Customer.query.count()

    products = Product.query.all()
    customers = Customer.query.all()
    orders = Order.query.all()

    pending = sum(1 for o in orders if o.status == 'Pending')
    processing = sum(1 for o in orders if o.status == 'Processing')
    shipped = sum(1 for o in orders if o.status == 'Shipped')

    # Load products for the product section
    search = request.args.get('search', '')
    sort_by = request.args.get('sort', 'name')
    direction = request.args.get('direction', 'asc')
    page = int(request.args.get('page', 1))
    per_page = 5

    query = "SELECT * FROM product WHERE name LIKE ? ORDER BY {} {}".format(
        sort_by,
        'ASC' if direction == 'asc' else 'DESC'
    )
    products = db.execute(query, ('%' + search + '%',)).fetchall()
    total = db.execute("SELECT COUNT(*) FROM product WHERE name LIKE ?", ('%' + search + '%',)).fetchone()[0]

    class Pagination:
        def __init__(self, page, per_page, total):
            self.page = page
            self.per_page = per_page
            self.total = total
            self.pages = (total + per_page - 1) // per_page

    pagination = Pagination(page, per_page, total)

    return render_template('admin_dashboard.html',
                           total_products=total_products,
                           total_customers=total_customers,
                           pending=pending,
                           processing=processing,
                           shipped=shipped,
                           products=products,
                           customers=customers,
                           search=search,
                           sort_by=sort_by,
                           direction=direction,
                           pagination=pagination)


@app.route('/admin/products/data')
def get_products_data():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    sort_by = request.args.get('sort', 'name')
    direction = request.args.get('direction', 'asc')

    query = Product.query

    if search:
        query = query.filter(Product.name.ilike(f"%{search}%"))

    if direction == 'asc':
        query = query.order_by(asc(getattr(Product, sort_by)))
    else:
        query = query.order_by(desc(getattr(Product, sort_by)))

    pagination = query.paginate(page=page, per_page=20)
    
    return jsonify({
        'products': [{
            'id': p.id,
            'name': p.name,
            'price': p.price,
            'stock_quantity': p.stock_quantity,
            'description': p.description
        } for p in pagination.items],
        'total_pages': pagination.pages,
        'current_page': pagination.page
    })

# Product List with Pagination, Search, and Sort
@app.route('/admin/dashboard')
def admin_products():
    page = request.args.get('page', 1, type=int)
    search = request.args.get('search', '')
    sort_by = request.args.get('sort', 'name')
    direction = request.args.get('direction', 'asc')

    customers = db.execute("SELECT * FROM user WHERE role = 'customer'").fetchall()

    query = Product.query

    if search:
        query = query.filter(Product.name.ilike(f"%{search}%"))

    if direction == 'asc':
        query = query.order_by(asc(getattr(Product, sort_by)))
    else:
        query = query.order_by(desc(getattr(Product, sort_by)))

    pagination = query.paginate(page=page, per_page=20)
    return render_template('admin_dashboard.html',customers=customers, products=pagination.items, pagination=pagination, search=search, sort_by=sort_by, direction=direction)



@app.route('/admin/products/add', methods=['POST'])
def add_product():
    name = request.form['name']
    description = request.form['description']
    price = float(request.form['price'])
    stock_quantity = int(request.form['stock_quantity'])

    new_product = Product(
        name=name,
        description=description,
        price=price,
        stock_quantity=stock_quantity
    )
    db.session.add(new_product)
    db.session.commit()

    flash("Brownie added successfully!", "success")
    return redirect(url_for('admin_dashboard'))  # ✅ Go back to dashboard


# Update Product
@app.route('/admin/products/update/<int:product_id>', methods=['POST'])
def update_product(product_id):
    product = Product.query.get_or_404(product_id)
    product.name = request.form['name']
    product.description = request.form['description']
    product.price = float(request.form['price'])
    product.stock_quantity = int(request.form['stock_quantity'])
    db.session.commit()
    flash("Product updated!", "success")
    return redirect(url_for('admin_products'))

# Delete Product
@app.route('/admin/products/delete/<int:product_id>', methods=['POST'])
def delete_product(product_id):
    product = Product.query.get_or_404(product_id)
    db.session.delete(product)
    db.session.commit()
    flash("Product deleted!", "info")
    return redirect(url_for('admin_products'))



@app.route('/admin/customers')
def admin_customers():
    search = request.args.get('search', '')
    status_filter = request.args.get('status', 'all')

    query = Customer.query

    if search:
        query = query.filter(
            (Customer.name.ilike(f'%{search}%')) |
            (Customer.email.ilike(f'%{search}%'))
        )

    if status_filter != 'all':
        active_status = True if status_filter == 'active' else False
        query = query.filter(Customer.active == active_status)

    customers = query.all()
    return render_template('customers.html', customers=customers)

@app.route('/admin/customer/<int:customer_id>')
def view_customer(customer_id):
    customer = Customer.query.get_or_404(customer_id)
    orders = Order.query.filter_by(customer_id=customer.id).all()
    return render_template('customer_profile.html', customer=customer, orders=orders)

@app.route('/admin/customer/toggle/<int:customer_id>')
def toggle_customer_status(customer_id):
    customer = Customer.query.get_or_404(customer_id)
    customer.active = not customer.active
    db.session.commit()
    return redirect(url_for('admin_customers'))

@app.route('/admin/customer/delete/<int:customer_id>', methods=['POST'])
def delete_customer(customer_id):
    customer = Customer.query.get_or_404(customer_id)
    db.session.delete(customer)
    db.session.commit()
    flash('Customer deleted successfully.')
    return redirect(url_for('admin_customers'))

@app.route('/admin/customer/reset_password/<int:customer_id>', methods=['POST'])
def reset_password(customer_id):
    customer = Customer.query.get_or_404(customer_id)
    temp_password = ''.join(random.choices(string.ascii_letters + string.digits, k=8))
    hashed = bcrypt.generate_password_hash(temp_password).decode('utf-8')
    customer.password = hashed
    db.session.commit()
    flash(f"Temporary password: {temp_password}")
    return redirect(url_for('view_customer', customer_id=customer_id))

@app.route('/admin/customer/impersonate/<int:customer_id>')
def impersonate_customer(customer_id):
    customer = Customer.query.get_or_404(customer_id)
    session['impersonated_customer_id'] = customer.id
    session['original_admin'] = True
    return redirect('/customer/dashboard')  # Assume you have customer dashboard

@app.route('/admin/stop_impersonation')
def stop_impersonation():
    session.pop('impersonated_customer_id', None)
    session.pop('original_admin', None)
    return redirect('/admin/dashboard')


@app.route('/admin/orders')
def admin_orders():
    orders = Order.query.all()  # Assuming you have an Order model
    return render_template('orders.html')

@app.route('/logout')
def logout():
    response = make_response(redirect(url_for('index')))  # Redirect to homepage or wherever you want
    unset_jwt_cookies(response)  # Clear the JWT cookies
    return response


@app.route('/admin/settings', methods=['GET', 'POST'])
def admin_settings():
    if request.method == 'POST':
        html_content = request.form.get('editor_html')
        print("Received HTML content from Quill Editor:\n", html_content)
        # TODO: Save to DB if needed
        return redirect(url_for('admin_settings'))

    return render_template('settings.html')


if __name__ == '__main__':

    app.run(debug=True)