import sqlite3

conn = sqlite3.connect('users.db')  # Connects to users.db
cursor = conn.cursor()

cursor.execute('''
CREATE TABLE IF NOT EXISTS user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT CHECK(role IN ('admin', 'customer')) NOT NULL
);
''')

conn.commit()
conn.close()

print("✅ 'user' table created successfully.")
